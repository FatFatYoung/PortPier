# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['gui_client.py'],
    pathex=[],
    binaries=[],
    datas=[],
    hiddenimports=['asyncio', 'hashlib', 'base64', 'struct', 'tkinter', 'tkinter.ttk', 'tkinter.messagebox', 'tkinter.scrolledtext', 'i18n'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=['aiohttp', 'aiohttp_retry', 'aiohttp_socks', 'numpy', 'PIL', 'pillow', 'matplotlib', 'pandas', 'scipy', 'PyQt5', 'PyQt6', 'wx'],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='portpier_client',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
